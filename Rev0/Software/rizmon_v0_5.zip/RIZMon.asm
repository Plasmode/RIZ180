;check RAM
;RAM is at 0x40000
CFdata   	equ 010h    	;CF data register
CFerr    	equ 011h    	;CF error reg
CFsectcnt equ 012h    	;CF sector count reg
CF07     	equ 013h   	;CF LA0-7
CF815    	equ 014h       	;CF LA8-15
CF1623   	equ 015h       	;CF LA16-23
CF2427   	equ 016h       	;CF LA24-27
CFstat   	equ 017h       	;CF status/command reg

	org 0
	jp 100h
	org 100h
	ld a,0c0h		;relocate I/O register to 0xC0
	out0 (3fh),a
	ld a,4fh		;map RAM physical base, so page $5b mapped to logical 0xc000
	out0 (0f8h),a	;write to common base reg
	ld a,0c0h		;common area is 0xc000-0xffff
	out0 (0fah),a	;set common/bank register
	ld hl,0b000h	;source
	ld de,0c000h	;destination
	ld bc,1000h	;copy 4K from EPROM into RAM
	ldir
	ld a,50h		;by changing mapping of RAM physical base, I move copied program to 0xb000
	out0 (0f8h),a	;
	ld a,80h		;common area is 0x8000-8xFFFF
	out0 (0fah),a
	jp 0b400h		

	org 0b400h
	jp start		;boot table
	jp wboot		;warm boot
	jp cstat		;console input status
	jp cin		;console input
	jp cout		;console output
; variable area
testseed: ds 2		; RAM test seed value
addr3116	ds 2		; high address for Intel Hex format 4
RDsector	ds 1		; current RAM disk sector
RDtrack	ds 1		; current RAM disk track 
RDaddr	ds 2		; current RAM disk address 
sectoff	ds 2		; offset from a track & sector
readbsysav	ds 1	;scratch memory for readbsy routine

start:
	ld a,00h		;all memory are now RAM
	out0 (0fah),a
	ld a,64h		;transmit, receive enable, 8-bit 1 stop
	out0 (0c0h),a
	xor a
	out0 (0c2h),a	;divided by 160, 38400 with 12.288MHz clock

	ld sp,0b400h	;set stack just below the program
	ld hl,signon$
	call strout
	call readbsy	;;8 wait until busy flag is cleared
	jr nz,NoCF	;readbsy return Z flag clear if timed out
	ld a,0e0h		;;8 set up LBA mode
	out (CF2427),a	;;8
	ld a,1		;;8 set feature to 8-bit interface
	out (CFerr),a	;;8
	ld a,0efh		;;8 set feature command
	out (CFstat),a	;;8

	xor a
	ld (sectoff),a	;initialize (clear) sector offset
	ld (sectoff+1),a
	jr nxt1
NoCF:
	ld hl,NoCF$
	call strout
nxt1:
	ld hl,251		; initialize RAM test seed value
	ld (testseed),hl	; save it
wboot:
clrRx:
	call cstat
	jr z,CMD
	call cin
	jr clrRx
CMD:
	ld hl,prompt$
	call strout
CMDLP1:
        	call cinq
	cp ':'		; Is this Intel load file?
	jp z,initload
	cp 0ah		; ignore line feed
	jr z,CMDLP1
	cp 0dh		; carriage return get a new prompt
	jr z,CMD
	call cout		; echo character
        	and 5Fh
	cp 'H'		; help command
	jp z,help
        	CP A,'D'
        	JP Z,MEMDMP
        	CP A,'E'
       	JP Z,EDMEM
	cp a,'I'		; read data from specified I/O port in page 0
	jp z,INPORT
	cp a,'O'		; write data to specified I/O port in page 0
	jp z,OUTPORT
;	cp a,'L'		; list memory as Intel Hex format
;	jp z,LISTHEX
        	CP A,'G'
        	JP Z,go
	cp a,'R'		; read a CF sector
	jp z,readCF
	cp a,'Z'		; fill memory with zeros
	jp z,fillZ
	cp a,'F'		; fill memory with ff
	jp z,fillF
	cp a,'C'		; Copy to CF	
	jp z,copyCF
	cp a,'T'		; testing RAM 
	jp z,testRAM
	cp 'B'		; boot CPM
	jp z,BootCPM
	cp 'X'		; clear RAMdisk directory at 0x80000
	jp z,format
what:
        	ld hl,what$
        	CALL strout
        	jr CMD
abort:
	ld hl,abort$	; print command not executed
	call strout
	jr CMD
readbsy:
; spin on CF status busy bit
;Z flag set (equal) if CF not busy
;Z flag reset (not equal) if timed out
	ld (readbsysav),a	;save reg A
	push de
	push bc
	ld de,0		;set a timeout limit
	ld bc,30
readbsy1
	inc de
	ld a,d
	or e
	jr nz,moreRdBsy
	dec c
	jr nz,moreRdBsy
	xor a
	inc a		;clear Z flag
	pop bc
	pop de
	ld a,(readbsysav)	;restore regA, but not status flags
	ret
moreRdBsy:
	in a,(CFstat)	; read CF status 
	and 80h		; mask off all except busy bit
	jr nz,readbsy1
	pop bc
	pop de
	ld a,(readbsysav)	;restore regA, but not status flags
	ret
; initialize for file load operation
initload:
	ld hl,0		; clear the high address in preparation for file load
	ld (addr3116),hl	; addr3116 modified with Intel Hex format 4 
; load Intel file
fileload:
	call GETHEXQ	; get two ASCII char (byte count) into hex byte in reg A
	ld d,a		; save byte count to reg D
	ld c,a		; save copy of byte count to reg C
	ld b,a		; initialize the checksum
	call GETHEXQ	; get MSB of address
	ld h,a		; HL points to memory to be loaded
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get LSB of address
	ld l,a
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get the record type, 0 is data, 1 is end
	cp 0
	jp z,filesave
	cp 1		; end of file transfer?
	jp z,fileend
	cp 4		; Extended linear address?
	jp nz,unknown	; if not, print a 'U'
; Extended linear address for greater than 64K
; this is where addr3116 is modified
	add a,b		; accumulating checksum of record type
	ld b,a		; checksum is kept in reg B
	ld a,d		; byte count should always be 2
	cp 2
	jp nz,unknown
	call GETHEXQ	; get first byte (MSB) of high address
	ld (addr3116+1),a	; save to addr3116+1
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
; Little Endian format.  MSB in addr3116+1, LSB in addr3116
	call GETHEXQ	; get the 2nd byte (LSB) of of high address
	ld (addr3116),a	; save to addr3116
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get the checksum
	neg a		; 2's complement
	cp b		; compare to checksum accumulated in reg B
	jp nz,badload	; checksum not match, put '?'
	ld a,'E'		; denote a successful Extended linear addr update
	jp filesav2
; end of the file load
fileend:
	call GETHEXQ	; flush the line, get the last byte
	ld hl,loadX$
	call strout
	jp CMD
; the assumption is the data is good and will be saved to the destination memory
filesave:
	add a,b		; accumulating checksum of record type
	ld b,a		; checksum is kept in reg B
	ld ix,0c000h	; 0c000h is buffer for incoming data
filesavx:
	call GETHEXQ	; get a byte
;	ld (ix),a		; save to buffer
	ld (hl),a		;save data to destination
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	inc ix
	inc hl
	dec d
	jp nz,filesavx
	call GETHEXQ	; get the checksum
	neg a		; 2's complement
	cp b		; compare to checksum accumulated in reg B
	jp nz,badload	; checksum not match, put '?'
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;DMA operation
;;;;;;;;;;;;;;;;;;;;;;;;;;;
	ld a,'.'		; checksum match, put '.'
filesav2:
	call cout
	jr flushln	; repeat until record end
badload:
	ld a,'?'		; checksum not match, put '?'
	jr filesav2
unknown:
	ld a,'U'		; put out a 'U' and wait for next record
	call cout
flushln:
	call cinq		; keep on reading until ':' is encountered
	cp ':'
	jr nz,flushln
	jp fileload

testRAM:
; test memory from top of this program to 0xFFFE 
	ld hl,testram$	; print test ram message
	call strout
	ld hl,confirm$	; get confirmation before executing
	call strout
	call tstCRLF	; check for carriage return
	jp nz,abort
	ld iy,(testseed)	; a prime number seed, another good prime number is 211
TRagain:
	ld hl,PROGEND	; start testing from the end of this program
	ld de,137		; increment by prime number
TRLOOP:
	push iy		; bounce off stack
	pop bc
	ld (hl),c		; write a pattern to memory
	inc hl
	ld (hl),b
	inc hl
	add iy,de		; add a prime number
	ld a,0ffh		; compare h to 0xff
	cp h
	jp nz,TRLOOP	; continue until reaching 0xFFFE
	ld a,0feh		; compare l to 0xFE
	cp l
	jp nz,TRLOOP
	ld hl,0b000h	; test memory from 0xAFFF down to 0x0000
TR1LOOP:
	push iy
	pop bc		; bounce off stack
	dec hl
	ld (hl),b		; write MSB
	dec hl
	ld (hl),c		; write LSB
	add iy,de		; add a prime number
	ld a,h		; check h=l=0
	or l
	jp nz,TR1LOOP
	ld hl,PROGEND	; verify starting from the end of this program
	ld iy,(testseed)	; starting seed value
TRVER:
	push iy		; bounce off stack
	pop bc
	ld a,(hl)		; get LSB
	cp c		; verify
	jp nz,TRERROR
	inc hl
	ld a,(hl)		; get MSB
	cp b
	jp nz,TRERROR
	inc hl
	add iy,de		; next reference value
	ld a,0ffh		; compare h to 0xff
	cp h
	jp nz,TRVER	; continue verifying til end of memory
	ld a,0feh		; compare l to 0xFE
	cp l
	jp nz,TRVER
	ld hl,0b000h	; verify memory from 0xB000 down to 0x0000
TR1VER:
	push iy		; bounce off stack
	pop bc
	dec hl
	ld a,(hl)		; get MSB from memory
	cp b		; verify
	jp nz,TRERROR
	dec hl
	ld a,(hl)		; get LSB from memory
	cp c
	jp nz,TRERROR
	add iy,de
	ld a,h		; check h=l=0
	or l
	jp nz,TR1VER
	ld hl,ok$		;put out an 'OK' message
	call strout
	ld (testseed),iy	; save seed value

	call cstat
	jp z,TRagain	;no keyboard input, do another iteration of memory test
	call cin

	jp CMD
TRERROR:
	push hl		;save HL
	ld hl,RAMerr$
	call strout
	pop hl
;	call SPCOUT	; a space char to separate the 'r' command
;	ld a,'H'		; display content of HL reg
;	call COUT		; print the HL label
;	ld a,'L'
;	call COUT
;	call SPCOUT	
	call ADROUT	; output the content of HL 	
	jp CMD
; Read CF disk
; data buffer is at 0x1000
; previous data is at 0x2000 for comparison to current data
readCF:
	ld hl,read$	; put out read command message
	call strout
	ld hl,track$	; enter track in hex value
	call strout
	call GETHEX	; get a byte of hex value as track
	ld (RDtrack),a	; save it 
	ld hl,sector$	; enter sector in hex value
	call strout
	call GETHEX	; get a byte of hex value as sector
	ld (RDsector),a	; save it
READRD1:
	ld hl,1000h	; copy previous block to 2000h
	ld de,2000h
	ld bc,200h	; copy 512 bytes
	ldir		; block copy
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	ld a,1		; read 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,0		; read first sector
	out (CF1623),a	; high byte of track is always 0
	ld a,(RDsector)	;Z80SBC get sector value
	out (CF07),a	; write sector
	ld a,(RDtrack)
	out (CF815),a
	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
;readdrq:
;	in a,(CFstat)	; check data request bit set before read CF data
;	and 8		; bit 3 is DRQ, wait for it to set
;	jp z,readdrq
	call chkdrq	;check data request bit set before write CF data
	ld hl,1000h	; store CF data starting from 1000h
	ld c,CFdata	; reg C points to CF data reg
	ld b,0h		; sector has 256 16-bit data
	inir		;Z80SBC
	inir
dumpdata:
	ld d,32		; 32 lines of data
	ld hl,1000h	; display 512 bytes of data
dmpdata1:
	push hl		; save hl
	ld hl,CRLF$	; add a CRLF per line
	call strout
	pop hl		; hl is the next address to display
	call DMP16TS	; display 16 bytes per line
	dec d
	jr nz,dmpdata1

	ld hl,1000h	; compare with data block in 2000h
	ld bc,200h
	ld de,2000h
blkcmp:
	ld a,(de)		; get a byte from block in 2000h
	inc de
	cpi		; compare with corresponding data in 1000h
	jp po,blkcmp1	; exit at end of block compare
	jr z,blkcmp	; exit if data not compare
	ld hl,notsame$	; send out message that data not same as previous read
	call strout
	jr chkRDmore
blkcmp1:	
	ld hl,issame$	; send out message that data read is same as before
	call strout

chkRDmore:
	ld hl,0		;clear sector offset value
	ld (sectoff),hl
	ld hl,RDmore$	; carriage return for next sector of data
	call strout
	call tstCRLF	; look for CRLF
	jp nz,CMD		; 
	ld hl,(RDsector)	; load track & sector as 16-bit value
	inc hl		; increment by 1
	ld (RDsector),hl	; save updated values
	ld hl,track$	; print track & sector value
	call strout
	ld a,(RDtrack)
	call strout
	ld hl,sector$
	call strout
	ld a,(RDsector)
	call HEXOUT
	jp READRD1

chkdrq:
	in a,(CFstat)	; check data request bit set before write CF data
	and 8		; bit 3 is DRQ, wait for it to set
	jr z,chkdrq
	ret
; drive A directory is track 1, sectors 0-0x1F
; drive B directory is track 0x40, sectors 0-0x1F
; drive C directory is track 0x80, sectors 0-0x1F
; drive D directory is track 0xC0, sectors 0-0x1F
format:
	ld hl,clrdir$	; command message
	call strout
	call cin
	cp 'A'
	jr z,formatA	; fill track 1 sectors 0-0x1F with 0xE5
	cp 'B'
	jr z,formatB	; fill track 0x40 sectors 0-0x1F with 0xE5
	cp 'C'
	jr z,formatC	; fill track 0x80 sectors 0-0x1F with 0xE5
	cp 'D'
	jr z,formatD	; fill track 0xC0 sectors 0-0x1F with 0xE5
	jp abort		; abort command if not in the list of options
formatA:
	ld de,100h	; start with track 1 sector 0
	jr doformat
formatB:
	ld de,4000h	; start with track 0x40 sector 0
	jr doformat
formatC:
	ld de,8000h	; start with track 0x80 sector 0
	jr doformat
formatD:
	ld de,0c000h	; start with track 0xC0 sector 0
doformat:
	ld hl,confirm$	; confirm command execution
	call strout
	call tstCRLF
	jp nz,abort	; abort command if not CRLF
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	xor a		; clear reg A
	out (CF1623),a	; MSB track is 0
	ld a,d		; reg D contains the track info
	out (CF815),a
	ld c,CFdata	; reg C points to CF data reg
	ld hl,0e5e5h	; value for empty directories
wrCFf:
	ld a,1		; write 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,e		; write CPM sector
	cp 20h		; format sector 0-0x1F
	jp z,wrCFdonef	; done formatting
	out (CF07),a	; 
	ld a,30h		; write sector command
	out (CFstat),a	; issue the write sector command
	call chkdrq	; check data request bit set before write CF data

	ld b,0h		; sector has 256 16-bit data
loopf:
	out (c),h		;z80 writes 2 bytes to CF
	out (c),h	
	inc b
	jp nz,loopf
	call readbsy	;wait on CF status busy bit

	inc e		; write next sector
	jp wrCFf
wrCFdonef:
	jp CMD

; boot CPM
; copy program from LA9-LA26 (9K) to 0xDC00
; jump to 0xF200 after copy is completed.
BootCPM:
	ld hl,bootcpm$	; print command message
	call strout
	call cin		; get input
	cp '1'		; '1' is user apps
	jp z,bootApps
	cp '2'		; '2' is cpm2.2
	jp z,boot22
	cp '3'		; '3' is cpm3, not implemented
	jp z,boot3
	jp what
boot3:
	ld hl,confirm$	; CRLF to execute the command
	call strout
	call tstCRLF
	jp nz,abort	; abort command if no CRLF
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	xor a		; clear reg A
	out (CF1623),a	; track 0
	out (CF815),a
	ld hl,1100h	; CPM3LDR starts from 0x1100
	ld c,CFdata	; reg C points to CF data reg
	ld d,1h		; read from LA 1 to LA 0x0f, 7K--much bigger than needed
readCPM3:
	ld a,1		; read 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; read CPM sector
	cp 10h		; between LA1 and LA0fh
	jp z,goCPM3	; done copying, execute CPM
	out (CF07),a	; 
	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
	call chkdrq	;check data request bit set before write CF data
	ld b,0h		; sector has 256 16-bit data
	inir		;z80 read 256 bytes
	ld b,0h		;z80
	inir		;z80 read 256 bytes

	inc d		; read next sector
	jp readCPM3
goCPM3:
	jp 01100h		; BIOS starting address of CP/M

boot22:
	ld hl,confirm$	; CRLF to execute the command
	call strout
	call tstCRLF
	jp nz,abort	; abort command if no CRLF
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	xor a		; clear reg A
	out (CF1623),a	; track 0
	out (CF815),a
	ld hl,0dc00h	; CPM starts from 0xDC00 to 0xFFFF
	ld c,CFdata	; reg C points to CF data reg
	ld d,80h		; read from LA 0x80 to LA 0x92
readCPM1:
	ld a,1		; read 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; read CPM sector
	cp 92h		; between LA80h and LA91h
	jp z,goCPM	; done copying, execute CPM
	out (CF07),a	; 
	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
	call chkdrq	; check data request bit set before write CF data
	ld b,0h		; sector has 256 16-bit data
	inir		;z80 read 256 bytes
	ld b,0h		;z80
	inir		;z80 read 256 bytes

	inc d		; read next sector
	jp readCPM1
goCPM:
	jp 0f200h		; BIOS starting address of CP/M

bootApps:
;restore user application from CF disk to 0x0-0xAFFF
;jump to 0 when done
	ld hl,confirm$	; CRLF to execute the command
	call strout
	call tstCRLF
	jp nz,abort	; abort command if no CRLF

	xor a		; clear reg A
	out (CF1623),a	; track 0
	out (CF815),a
	ld hl,0		; user apps starts from 0x0 to 0xAFFF
	ld c,CFdata	; reg C points to CF data reg
	ld d,11h		; read from LA 0x11 to LA 0x70
readApps:
	ld a,1		; read 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; read CPM sector
	cp 71h		; between LA11h and LA70h
	jp z,goApp	; done copying, execute CPM
	out (CF07),a	; 
	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
	call chkdrq	; check data request bit set before write CF data
	ld b,0h		; sector has 256 16-bit data
	inir		;z80 read 256 bytes
	ld b,0h		;z80
	inir		;z80 read 256 bytes

	inc d		; read next sector
	jp readApps
goApp:
	jp 0		; User apps starts from 0x0

; Write CF
;  allowable parameters are '1' for memory from 0x0 to 0xAFFF,
;   '2' for CPM2.2, '3' for CPM3
copyCF:
	ld hl,copycf$	; print copy message
	call strout
	call cin		; get write parameters
	cp '1'
	jp z,cpApps
	cp '2'
	jp z,CopyCPM2
	cp '3'
	jp z,CopyCPM3
	jp what		; error, abort command

	jp CMD


; write CPM to CF
; write data from 0xDC00 to 0xFFFF to CF LA128-LA146 (9K)
CopyCPM2:
	ld hl,0dc00h	; CPM starts from 0xDC00 to 0xFFFF
	ld de,8092h	; reg DE contains beginning sector and end sector values
	jp wrCF
CopyCPM3:
	ld hl,1100h	; CPMLDR starts from 0x1100
	ld de,0110h	; reg DE contains beginning sector and end sector values
	jp wrCF
cpApps:
; copy the memory contents below 0xB000 to CF flash
	ld hl,0		;start from 0x0
	ld de,1170h	;sectors 11 to sector 70
	jp wrCF

wrCF:
	push hl		; save value
	ld hl,confirm$	; carriage return to execute the program
	call strout
	pop hl
	call tstCRLF
	jp nz,CMD		; abort command if not CR or LF
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	xor a		; clear reg A
	out (CF1623),a	; track 0
	out (CF815),a
	ld c,CFdata	; reg C points to CF data reg
wrCF1:
	ld a,1		; write 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; write CPM sector
	cp e		; reg E contains end sector value
	jp z,wrCFdone	; done copying, execute CPM
	out (CF07),a	; 
	ld a,30h		; write sector command
	out (CFstat),a	; issue the write sector command
	call chkdrq	; check data request bit set before write CF data
	ld b,0h		; sector has 256 16-bit data
	otir		;z80 write 256 bytes
	ld b,0h		;z80
	otir		;z80 wrute 256 bytes

	call readbsy	;wait until busy flag is cleared

	inc d		; write next sector
	jp wrCF1
wrCFdone:
	jp CMD
	










INPORT:
; read data from specified I/O port in page 0
; command format is "I port#"
; 
	ld hl,inport$	; print command 'I' prompt
	call strout
	call GETHEX	; get port # into reg A
	ld c,a		;load port # in C
	ld b,0		;read from page 0
	in a,(c)		; get data from port # 
	push af
	ld hl,invalue$
	call strout
	pop af
	call HEXOUT
	jp CMD
OUTPORT:
; write data to specified I/O port in page 0
; command format is "O value port#"
	ld hl,outport$	; print command 'O' prompt
	call strout
	call GETHEX	; get value to be output
	push af
	ld hl,outport2$	; print additional prompt for command 'O'
	call strout
	call GETHEX	; get port number into reg A
	ld c,a
	ld b,0		;write to page 0
	pop af
	out (c),a		; output data in regB to port in reg C
	jp CMD

;Get an address and jump to it
go:
	ld hl,go$		; print go command message
	call strout
        	CALL ADRIN
        	LD H,D
        	LD L,E
	push hl		; save go address
	ld hl,confirm$	; get confirmation before executing
	call strout
	call tstCRLF	; check for carriage return
	pop hl
	jp nz,abort
	jp (hl)		; jump to address if CRLF

; fill memory from 0x8000 0xFFFF with zero or 0xFF

fillZ:
	ld hl,fill0$	; print fill memory with 0 message
	call strout
	ld b,0		; fill memory with 0
	jr dofill
fillF:
	ld hl,fillf$	; print fill memory with F message
	call strout
	ld b,0ffh		; fill memory with ff
dofill:
	ld hl,confirm$	; get confirmation before executing
	call strout
	call tstCRLF	; check for carriage return
	jp nz,abort
	ld hl,PROGEND	; start from 0x8000
	ld a,0ffh		; end address in reg A
filla:
	ld (hl),b		; write memory location
	inc hl
	cp h		; reached 0xFF00?
	jr nz,filla	; continue til done
	cp l		; reached 0xFFFF?
	jr nz,filla
	ld hl,0b000h	; fill value from 0xB000 down to 0x0000
fillb:
	dec hl
	ld (hl),b		; write memory location with desired value
	ld a,h		; do until h=l=0
	or l
	jr nz,fillb
	jp CMD

; print help message
help:
	ld hl,help$	; print help message
	call strout
	jp CMD

;;;;;;;;;;;;;;;;;;;;;;;;;;; Utilities from Glitch Works ver 0.1 ;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;; Copyright (C) 2012 Jonathan Chapman ;;;;;;;;;;;;;;;;;;

;Edit memory from a starting address until X is
;pressed. Display mem loc, contents, and results
;of write.
EDMEM:  	CALL SPCOUT
        	CALL ADRIN
        	LD H,D
        	LD L,E
ED1:    	LD A,13
        	CALL cout
        	LD A,10
        	CALL cout
        	CALL ADROUT
        	CALL SPCOUT
        	LD A,':'
        	CALL cout
        	CALL SPCOUT
        	CALL DMPLOC
        	CALL SPCOUT
        	CALL GETHEX
        	JP C,CMD
        	LD (HL),A
        	CALL SPCOUT
        	CALL DMPLOC
        	INC HL
        	JP ED1

;Dump memory between two address locations
MEMDMP: 	CALL SPCOUT
        	CALL ADRIN
        	LD H,D
        	LD L,E
        	LD C,10h
        	CALL SPCOUT
        	CALL ADRIN
MD1:    	LD A,13
        	CALL cout
        	LD A,10
        	CALL cout
        	CALL DMP16
        	LD A,D
        	CP H
        	JP M,CMD
        	LD A,E
        	CP L
        	JP M,MD2
        	JP MD1
MD2:    	LD A,D
        	CP H
        	JP NZ,MD1
        	JP CMD

DMP16TS:
; dump memory pointed by HL, 
; print offset from the given track & sector values
;  as the address field
	push hl		; save reg
	ld a,'+'		;print offset symbol
	call cout
	ld hl,(sectoff)	;get offset from track&sector base
	call ADROUT	; output A23..A8
	push bc		;save reg
	ld bc,10h		;add 16 to offset
	add hl,bc
	pop bc
	ld (sectoff),hl	;save it
	pop hl		; restore reg
	jp DMP16D		; display the 16 data field

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;DMP16 -- Dump 16 consecutive memory locations
;
;pre: HL pair contains starting memory address
;post: memory from HL to HL + 16 printed
;post: HL incremented to HL + 16
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
DMP16:  	CALL ADROUT
DMP16D:			; 16 consecutive data
        	CALL SPCOUT
        	LD A,':'
        	CALL cout
        	LD C,10h
	push hl		; save location for later use
DM1:    	CALL SPCOUT
        	CALL DMPLOC
        	INC HL		
        	DEC C
	jp nz,DM1

; display the ASCII equivalent of the hex values
	pop hl		; retrieve the saved location
	ld c,10h		; print 16 characters
	call SPCOUT	; insert two space
	call SPCOUT	; 
dm2:
	ld a,(hl)		; read the memory location
	cp ' '
	jp m,printdot	; if lesser than 0x20, print a dot
	cp 7fh
	jp m,printchar
printdot:
; for value lesser than 0x20 or 0x7f and greater, print '.'
	ld a,'.'
printchar:
; output printable character
	call cout
	inc hl
	dec c
	ret z
	jp dm2

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;DMPLOC -- Print a byte at HL to console
;
;pre: HL pair contains address of byte
;post: byte at HL printed to console
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
DMPLOC: 	LD A,(HL)
        	CALL HEXOUT
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;HEXOUT -- Output byte to console as hex
;
;pre: A register contains byte to be output
;post: byte is output to console as hex
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
HEXOUT: 	PUSH BC
        	LD B,A
        	RRCA
        	RRCA
        	RRCA
        	RRCA
        	AND 0Fh
        	CALL HEXASC
        	CALL cout
        	LD A,B
        	AND 0Fh
        	CALL HEXASC
        	CALL cout
        	POP BC
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;HEXASC -- Convert nybble to ASCII char
;
;pre: A register contains nybble
;post: A register contains ASCII char
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
HEXASC: 	ADD 90h
        	DAA
        	ADC A,40h
        	DAA
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;ADROUT -- Print an address to the console
;
;pre: HL pair contains address to print
;post: HL printed to console as hex
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
ADROUT: 	LD A,H
        	CALL HEXOUT
        	LD A,L
        	CALL HEXOUT
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;ADRIN -- Get an address word from console
;
;pre: none
;post: DE contains address from console
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
ADRIN:  	CALL GETHEX
        	LD D,A
        	CALL GETHEX
        	LD E,A
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;GETHEX -- Get byte from console as hex
;
;pre: none
;post: A register contains byte from hex input
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
GETHEX: 	PUSH DE
        	CALL cin
        	CP 'X'
        	JP Z,GE2
	cp 'x'		; exit with lower 'x'
	jp z,GE2
        	CALL ASCHEX
        	RLCA
        	RLCA
        	RLCA
        	RLCA
        	LD D,A
        	CALL cin
        	CALL ASCHEX
        	OR D
GE1:    	POP DE
        	RET
GE2:    	SCF
        	JP GE1

; get hex without echo back
GETHEXQ:
	push de		; save register 
        	CALL cinq
        	CALL ASCHEX
        	RLCA
        	RLCA
        	RLCA
        	RLCA
        	LD D,A
        	CALL cinq
        	CALL ASCHEX
        	OR D 
  	pop de			;restore register
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;ASCHEX -- Convert ASCII coded hex to nybble
;
;pre: A register contains ASCII coded nybble
;post: A register contains nybble
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
ASCHEX: 	SUB 30h
        	CP 0Ah
        	RET M
        	AND 5Fh
        	SUB 07h
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;GOBYT -- Push a two-byte instruction and RET
;         and jump to it
;
;pre: B register contains operand
;pre: C register contains opcode
;post: code executed, returns to caller
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
GOBYT:  	LD HL,0000
        	ADD HL,SP
        	DEC HL
        	LD (HL),0C9h
        	DEC HL
        	LD (HL),B
        	DEC HL
        	LD (HL),C
        	JP (HL)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;SPCOUT -- Print a space to the console
;
;pre: none
;post: 0x20 printed to console
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
SPCOUT: 	LD A,' '
        	CALL cout
        	RET

; test for CR or LF.  Echo back. return 0
tstCRLF:
	call cin		; get a character					
	cp 0dh		; if carriage return, output LF
	jp z,tstCRLF1
	cp 0ah		; if line feed, output CR 
	jp z,tstCRLF2
	ret
tstCRLF1:
	ld a,0ah		; put out a LF
	call cout
	xor a		; set Z flag
	ret
tstCRLF2:
	ld a,0dh		; put out a CR
	call cout
	xor a		; set Z flag
	ret


strout:
;output null-terminated string
	ld a,(hl)
	or a
	ret z
	call cout
	inc hl
	jr strout
cout:
;output char in regA
	push af
chkEmpty:
	in0 a,(0c4h)		;read status
	and 2
	jr z,chkEmpty
	pop af
	out0 (0c6h),a
	ret
cstat:
;check console input status, return 0 with Z set if no character available
	in0 a,(0c4h)		;read chan 0 status
	and 80h		;check receive data full
	ret
;
cin:
;return input character in regA
	in0 a,(0c4h)		;read status
	and 80h		;check receive data full
	jr z,cin
	in0 a,(0c8h)		;get character in regA
	out0 (0c6h),a	;echo
	ret
cinq:
;return input character in regA
;no echo back
	in0 a,(0c4h)		;read status
	and 80h		;check receive data full
	jr z,cinq
	in0 a,(0c8h)		;get character in regA
	ret
PROGEND	equ 0c000h	;mark the end of program at 0xC000

	org 0b000h
signon$:	db 10,13,"RIZ180 Monitor ver 0.5 11/22/20",10,13,0
NoCF$:	db 13,10,"no CF disk",13,10,0
prompt$:	db 13, 10, 10, ">", 0
what$:   	db 13, 10, "?", 0
CRLF$	db 13,10,0
confirm$	db " press Return to execute command",0
abort$	db 13,10,"command aborted",0
notdone$	db 13,10,"command not implemented",0
go$	db "o to address: 0x",0
track$	db " track:0x",0
sector$	db " sector:0x",0
read$	db "ead CF disk",0
RDmore$	db 10,13,"Return for next sector, any other key for command prompt",10,13,0
notsame$	db 10,13,"Data NOT same as previous read",10,13,0
issame$	db 10,13,"Data same as previous read",10,13,0
inport$	db "nput from port ",0
invalue$	db 10,13,"Value=",0
outport$	db "utput ",0
outport2$	db " to port ",0
listhex$	db "ist memory as Intel Hex, start address=",0
listhex1$	db " end address=",0
fillf$	db "ill memory with 0xFF",10,13,0
fill0$	db "ero memory",10,13,0
testram$	db "est memory",10,13,0
ok$	db " OK",0
RAMerr$	db " HL: ",0
loadX$	db "X",10,13,0
copycf$	db "opy to CF disk",10,13
;	db "0--boot,",10,13
	db "1--User Apps,",10,13
	db "2--CP/M2.2:",10,13
	db "3--CP/M3: ",0
	db 0
clrdir$	db " clear disk directories",10,13
	db "A -- drive A,",10,13
	db "B -- drive B:",10,13
	db "C -- drive C,",10,13
	db "D -- drive D,",10,13	
;	db "E -- RAM drive: ",0
	db 0
bootcpm$	db "oot CP/M",10,13
	db "1--User Apps,",10,13
	db "2--CP/M2.2:",10,13
	db "3--CP/M3: ",0
	db 0
help$	db "elp",13,10
	db "G <addr> CR",13,10
	db "R <track> <sector>",13,10
	db "D <start addr> <end addr>",13,10
	db "I <port>",13,10
	db "O <value> <port>",13,10
	db "L <start addr> <end addr>",13,10
	db "Z CR",13,10
	db "F CR",13,10
	db "T CR",13,10
	db "E <addr>",13,10
	db "X <options> CR",13,10
	db "B <options> CR",13,10
	db "C <options> CR",0

